"""
Модуль уведомлений
"""
from .telegram_notifier import TelegramNotifier

__all__ = ['TelegramNotifier']

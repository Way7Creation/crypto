"""
Модуль извлечения признаков
"""
from .feature_engineering import FeatureEngineering

__all__ = ['FeatureEngineering']

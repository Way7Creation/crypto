# Прокси для db_models (для обратной совместимости)
from .models import *

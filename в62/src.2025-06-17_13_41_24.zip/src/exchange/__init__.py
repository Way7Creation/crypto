"""
Модуль работы с биржами
"""
from .client import ExchangeClient

__all__ = ['ExchangeClient']
